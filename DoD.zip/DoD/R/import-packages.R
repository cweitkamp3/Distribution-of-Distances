#' @importFrom stats dist
#' @importFrom stats ecdf

NULL